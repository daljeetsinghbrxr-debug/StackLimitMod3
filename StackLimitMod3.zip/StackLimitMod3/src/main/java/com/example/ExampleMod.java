package net.fabricmc.example;

import net.minecraft.world.item.Item;

public class ModItems {
    public static final Item CUSTOM_ITEM = new Item(new Item.Properties().stacksTo(72));
}